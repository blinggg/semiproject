package stock;

import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


import database.Database;

public class StockDAO {
	// �����Ȳ������
	public JSONObject pslist(String cvs_code) {
		JSONObject jobject = new JSONObject();
		try {
			String sql = "select s.*, t.stock from sview s, sell_status t where s.cvs_code=t.cvs_code and s.product_code=t.product_code and t.cvs_code=?";
			PreparedStatement ps= Database.CON.prepareStatement(sql);
			ps.setString(1, cvs_code);
			ResultSet rs = ps.executeQuery();
			
			JSONArray jArray = new JSONArray();
			while (rs.next()) {
				JSONObject obj = new JSONObject();
				obj.put("cvs_code", rs.getString("cvs_code"));
				obj.put("cvs_name", rs.getString("cvs_name"));
				obj.put("ceo_name", rs.getString("ceo_name"));
				obj.put("category_code", rs.getString("category_code"));
				obj.put("product_code", rs.getInt("product_code"));
				obj.put("product_name", rs.getString("product_name"));
				obj.put("stock", rs.getInt("stock"));
			
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				
				String strDate = sdf.format(rs.getDate("product_date"));
				String strExp = sdf.format(rs.getDate("product_exp"));
				obj.put("product_date", strDate);
				obj.put("product_exp", strExp);
				jArray.add(obj);
			}
			jobject.put("array", jArray);
		
		} catch (Exception e) {
			System.out.println("�����Ȳ���" + e.toString());
		}
		return jobject;
	}
}
