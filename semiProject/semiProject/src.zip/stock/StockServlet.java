package stock;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import database.SqlVO;


@WebServlet(value= {"/stock/list"})
public class StockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=UTF-8"); 
	       PrintWriter out=response.getWriter();
	       StockDAO pdao=new StockDAO();
		switch(request.getServletPath()) {
	case "/stock/list":  
        String cvs_code=request.getParameter("cvs_code")==null?"C01":request.getParameter("cvs_code");
        out.println(pdao.pslist(cvs_code));
    } 
} 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
