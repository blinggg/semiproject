package stock;

import product.ProductVO;

public class SVO extends ProductVO{
	private String stock;

}
