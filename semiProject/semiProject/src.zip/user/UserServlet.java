package user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;

@WebServlet(value= {"/user/login","/user/logout"})
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      switch(request.getServletPath()) {
	      case "/user/logout":
	          HttpSession session=request.getSession();
	          session.invalidate();
	          response.sendRedirect("login.jsp");
	          break;
	      }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String id=request.getParameter("id");
		String pass=request.getParameter("pass");
		String name=request.getParameter("name");
		String sort=request.getParameter("sort");
		String email=request.getParameter("email");
		String tel=request.getParameter("tel");
		UserDAO udao=new UserDAO();
		
		switch(request.getServletPath()) {
		case "/user/login":
			UserVO uvo=udao.login(id);
			
			int check=0;	//id�� ���°��
			if(uvo.getId()!=null) {
				if(uvo.getPass().equals(pass)) {
					check=2;	//id�� password�� ��ġ�ϴ� ���
					HttpSession session=request.getSession();
		            session.setAttribute("id", uvo.getId());
		            session.setAttribute("name", uvo.getName());
				}else {
					check=1;	//id�� ������ password�� ��ġ���� �ʴ� ���
				}
			}
			JSONObject jObject=new JSONObject();
			jObject.put("check", check);
			out.print(jObject);
			System.out.println("check:"+check);
			break;
		}
	}

}